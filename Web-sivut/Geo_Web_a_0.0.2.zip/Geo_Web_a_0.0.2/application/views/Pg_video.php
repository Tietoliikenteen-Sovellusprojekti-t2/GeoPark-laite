
<?php
	include_once 'navbar.php';
?>

<!DOCTYPE html>
<html>
<head>
	<title>GeoPark</title>
</head>
<body>
	<table>
		<tr>
			<th>Video</th>
			
		</tr>
		<?php
	